/* UM_protocol.h - Header UM protocol for communitcation with UM module */

#ifndef _UM_H_
#define _UM_H_

#include <stdio.h>
#include <Arduino.h>
#include <avr/pgmspace.h>

#include <SPI.h>

#define UM_BUFF_MAX 32
#define UM_BUFF_CELL_MAX 32

/* @structure UMCellBuff	UM cell buffer store data for one time sending and receiving
 * throught UM communication.
 *
 * @member data		Cell data, max length is UM_BUFF_CELL_MAX
 * @member size		Size of cell data
 * */
typedef struct UMCellBuff {
	 byte data[UM_BUFF_CELL_MAX];
	 size_t size;
};

/* @structure UMRingBuff UM ring buffer that store all data ready for sending or received.
 *
 * @member ring		Array of UM Cell buffer
 * @member ringHead	Point to head cell of ring
 * @member ringTail Point to tail cell of ring
 */
typedef struct UMRingBuff {
	UMCellBuff ring[UM_BUFF_MAX];
	uint8_t ringHead;
	uint8_t ringTail;
};

class UMClass{

	public:
		UMClass();

		/* @function begin	Start UM module, intialzie hardware
		 */
		void begin();


		/* @function sendUMData		Exposed function for user to data to UM module.
		 *
		 * @param data	data buffer for reading
		 * @param size	number of byte writing
		 * 
		 * @return	number of byte sended.
		 */
		int sendUMData(byte *data, size_t size);
			
		/* @function end	Deinitialize UM module
		 */
		void end();
	private:
		SPIClass spi;
};

extern UMClass UM;

#endif
